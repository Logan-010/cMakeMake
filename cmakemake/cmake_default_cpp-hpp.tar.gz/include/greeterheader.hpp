#ifndef GREETERHEADER_H
#define GREETERHEADER_H

namespace greet {
    void hello();
}

#endif