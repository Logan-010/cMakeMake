#include "greeterheader.h"
#include <iostream>

namespace greet {
    void hello() {
        std::cout << "Hello, world!" << std::endl;
    }
}