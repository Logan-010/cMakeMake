# What is this?
a template cmake project

# Installing libraries

Package Managers (Recommended):
Many operating systems provide package managers that allow you to easily install and manage libraries. Examples include:

Linux (Debian/Ubuntu): Use apt-get or apt:
`sudo apt-get install liblibrary-dev`

Linux (Red Hat/Fedora): Use dnf or yum:
`sudo dnf install liblibrary-devel`

macOS (Homebrew):
`brew install library`

Windows (vcpkg):
Install vcpkg and then use it to install libraries:
`vcpkg install library`

To manually install:

Use CMake's FetchContent module to automatically download and build external libraries. This is particularly useful for libraries hosted on GitHub or other version control platforms.

(add to CMakeLists.txt)

```
include(FetchContent)

FetchContent_Declare(
    library_name
    GIT_REPOSITORY https://github.com/username/library_name.git
    GIT_TAG v1.0.0  # Use the desired version or commit hash
)

FetchContent_MakeAvailable(library_name)
```

# Linking libraries
add the following to CMakeLists.txt

```
find_package(libraryName REQUIRED)
include_directories(${libraryName_INCLUDE_DIRS})
target_link_libraries(programName PRIVATE ${libraryName_LIBRARIES} ${libraryName_INCLUDE_DIRS})
```
If the library is not found; use link_directories(/path/to/your/library)

# Building
```
mkdir build
cd build
cmake ..
make
```

# But i want to use c instead of c++ or headers++ instead of headers
fine, change 
```
# Add the source files to the project
file(GLOB SOURCES ${SOURCE_DIR}/*.cpp)

# Add the header files to the project
file(GLOB HEADERS ${INCLUDE_DIR}/*.h)
```
to your desired language