#include "greeterheader.h"
#include <stdio.h>

namespace greet {
    void hello() {
        printf("Hello World!\n");
    }
}