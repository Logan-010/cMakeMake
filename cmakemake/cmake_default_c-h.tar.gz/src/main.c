#include <stdio.h>
#include "greeterheader.h"

int main() {
    greet::hello();

    return 0;
}