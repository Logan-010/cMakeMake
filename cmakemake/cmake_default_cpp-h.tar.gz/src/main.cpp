#include <iostream>
#include "greeterheader.h"
using namespace std;

int main() {
    greet::hello();

    return 0;
}